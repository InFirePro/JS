<?php
// Database connection details (consider using environment variables for sensitive information)
$servername = getenv('DB_SERVER') ?: "spaas.mysql.tools"; // Server name
$username = getenv('DB_USER') ?: "spaas_bd";             // Database username
$password = getenv('DB_PASS') ?: "D@#5X3gi4n";           // Database password
$dbname = getenv('DB_NAME') ?: "spaas_bd";                // Database name

// Create a new MySQLi connection with error handling
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    // Log the error message
    error_log("Connection failed: " . $conn->connect_error);
    // Display a generic message to the user
    exit("Database connection error, please check the connection");
}

// Ensure the connection is set to use UTF-8 for character encoding
$conn->set_charset("utf8mb4");

// Make sure to close the connection when done
register_shutdown_function(function() use ($conn) {
    $conn->close();
});
?>


